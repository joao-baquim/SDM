package br.unibh.sdm.backend_estacionamento.entidades;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.boot.autoconfigure.context.PropertyPlaceholderAutoConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.amazonaws.client.builder.AwsClientBuilder;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClientBuilder;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;

import java.util.Date;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(SpringExtension.class)
@SpringBootTest(classes = {PropertyPlaceholderAutoConfiguration.class, VagaEstacionamentoTest.DynamoDBConfig.class})
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class VagaEstacionamentoTest {

    @Configuration
    static class DynamoDBConfig {
        @Bean
        public AmazonDynamoDB amazonDynamoDB() {
            return AmazonDynamoDBClientBuilder.standard()
                .withEndpointConfiguration(new AwsClientBuilder.EndpointConfiguration("http://localhost:8000", "us-west-2"))
                .build();
        }

        @Bean
        public DynamoDBMapper dynamoDBMapper() {
            return new DynamoDBMapper(amazonDynamoDB());
        }
    }

    private VagaEstacionamento vagaEstacionamento;
    private Date dataAtual;

    @BeforeEach
    public void setUp() {
        dataAtual = new Date();
        vagaEstacionamento = new VagaEstacionamento("1", "A1", true, dataAtual);
    }

    @Test
    public void testGetId() {
        assertEquals("1", vagaEstacionamento.getId());
    }

    @Test
    public void testSetId() {
        vagaEstacionamento.setId("2");
        assertEquals("2", vagaEstacionamento.getId());
    }

    @Test
    public void testGetLocalizacao() {
        assertEquals("A1", vagaEstacionamento.getLocalizacao());
    }

    @Test
    public void testSetLocalizacao() {
        vagaEstacionamento.setLocalizacao("B2");
        assertEquals("B2", vagaEstacionamento.getLocalizacao());
    }

    @Test
    public void testIsDisponivel() {
        assertTrue(vagaEstacionamento.isDisponivel());
    }

    @Test
    public void testSetDisponivel() {
        vagaEstacionamento.setDisponivel(false);
        assertFalse(vagaEstacionamento.isDisponivel());
    }

    @Test
    public void testGetDataUltimaAtualizacao() {
        assertEquals(dataAtual, vagaEstacionamento.getDataUltimaAtualizacao());
    }

    @Test
    public void testSetDataUltimaAtualizacao() {
        Date novaData = new Date();
        vagaEstacionamento.setDataUltimaAtualizacao(novaData);
        assertEquals(novaData, vagaEstacionamento.getDataUltimaAtualizacao());
    }

    @Test
    public void testToString() {
        String expected = "VagaEstacionamento [id=1, localizacao=A1, disponivel=true, dataUltimaAtualizacao=" + dataAtual + "]";
        assertEquals(expected, vagaEstacionamento.toString());
    }

    @Test
    public void testHashCode() {
        VagaEstacionamento outraVaga = new VagaEstacionamento("1", "A1", true, dataAtual);
        assertEquals(vagaEstacionamento.hashCode(), outraVaga.hashCode());
    }

    @Test
    public void testEquals() {
        VagaEstacionamento outraVaga = new VagaEstacionamento("1", "A1", true, dataAtual);
        assertTrue(vagaEstacionamento.equals(outraVaga));
        
        VagaEstacionamento diferenteVaga = new VagaEstacionamento("2", "B2", false, new Date());
        assertFalse(vagaEstacionamento.equals(diferenteVaga));
    }
}
