import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:iparking/cartas.dart';
import 'package:iparking/cartas_service.dart';
import 'package:iparking/estacionamento.dart';
import 'package:iparking/estacionamentodois.dart';
import 'package:iparking/estacionamentotres.dart';
import 'package:iparking/vagasalva.dart';
import 'package:toastification/toastification.dart';

void main() {
  runApp(const MeuApp());
}

class MeuApp extends StatelessWidget {
  const MeuApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Meu App',
      home: TelaPrincipal(),
    );
  }
}

class TelaPrincipal extends StatefulWidget {
  const TelaPrincipal({super.key});

  @override
  State<TelaPrincipal> createState() => _TelaPrincipalState();
}

class _TelaPrincipalState extends State<TelaPrincipal> {


  @override
  Widget build(BuildContext context) {

    return Scaffold(
      appBar: AppBar(
        foregroundColor: Color(Colors.black.value),
        backgroundColor: Color(Colors.yellow.value),
        title: Text('iParking'),
        actions: <Widget>[
          IconButton(
            icon: Icon(
              Icons.person,
              color: Colors.black,
            ),
            onPressed: () {
              // do something
            },
          )
        ],
      ),
      body: Container(
        color: Colors.white,
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: <Widget>[
              const Text("Estacionamentos proximos",
                  style: TextStyle(
                      fontSize: 20,
                      color: Colors.black,
                      fontWeight: FontWeight.bold)),
              GestureDetector(
                onTap: () {
                  Navigator.push(context,
                      MaterialPageRoute(builder: (context) => Estacionamento()));
                },
                child: Image.asset("assets/images/Lugar 3.jpg",
                    width: 180.0, height: 180.0),
              ),
              GestureDetector(
                onTap: () {
                  Navigator.push(context,
                      MaterialPageRoute(builder: (context) => Estacionamentodois()));
                },
                child: Image.asset("assets/images/lugar 4.jpg",
                    width: 180.0, height: 180.0),
              ),
              GestureDetector(
                onTap: () {
                  Navigator.push(context,
                      MaterialPageRoute(builder: (context) => Estacionamentotres()));
                },
                child: Image.asset("assets/images/lugar5.jpg",
                    width: 180.0, height: 180.0),
              ),

               Row(
                 mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: <Widget>[
                  Container(
                    child: IconButton(
                      icon: Icon(
                        Icons.home,
                        color: Colors.black,
                      ),
                      onPressed: (){
                      //  Navigator.push(context,
                           // MaterialPageRoute(builder: (context) => Estacionamentodois()));
                      },
                    ),
                  ),
                  Container(
                    child: IconButton(
                      icon: Icon(
                        Icons.add_business_sharp,
                        color: Colors.black,
                      ),
                      onPressed: (){
                        Navigator.push(context,
                            MaterialPageRoute(builder: (context) => Vagasalva()));
                      },
                    ),
                  ),
                  Container(
                    child: IconButton(
                      icon: Icon(
                        Icons.notifications,
                        color: Colors.black,
                      ),
                      onPressed: () {
                        toastification.show(
                          context: context, // optional if you use ToastificationWrapper
                          type: ToastificationType.success,
                          style: ToastificationStyle.flat,
                          autoCloseDuration: const Duration(seconds: 3),
                          title: Text('Sem notificações!'),

                          alignment: Alignment.bottomCenter,
                          direction: TextDirection.ltr,
                          animationDuration: const Duration(milliseconds: 300),

                          icon: const Icon(Icons.error_outline),
                          primaryColor: Colors.red,
                          backgroundColor: Colors.white,
                          foregroundColor: Colors.black,
                          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 16),
                          margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                          borderRadius: BorderRadius.circular(12),
                          boxShadow: const [
                            BoxShadow(
                              color: Color(0x07000000),
                              blurRadius: 16,
                              offset: Offset(0, 16),
                              spreadRadius: 0,
                            )
                          ],
                          showProgressBar: true,
                          closeButtonShowType: CloseButtonShowType.onHover,
                          closeOnClick: false,
                          pauseOnHover: true,
                          dragToClose: true,
                          applyBlurEffect: true,
                          callbacks: ToastificationCallbacks(
                            onTap: (toastItem) => print('Toast ${toastItem.id} tapped'),
                            onCloseButtonTap: (toastItem) => print('Toast ${toastItem.id} close button tapped'),
                            onAutoCompleteCompleted: (toastItem) => print('Toast ${toastItem.id} auto complete completed'),
                            onDismissed: (toastItem) => print('Toast ${toastItem.id} dismissed'),
                          ),
                        );
                      },
                    ),
                  ),



                ],
              )
            ],
          ),
        ),
      ),
    );
  }
}
