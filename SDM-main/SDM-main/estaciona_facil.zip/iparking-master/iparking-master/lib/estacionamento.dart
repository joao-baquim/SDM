
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:toastification/toastification.dart';


class Estacionamento extends StatefulWidget {
  const Estacionamento({super.key});

  @override
  State<Estacionamento> createState() => _EstacionamentoState();
}

class _EstacionamentoState extends State<Estacionamento> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Estapar'),
        actions: <Widget>[
          IconButton(
            icon: Icon(
              Icons.add_circle,
              color: Colors.black,
            ),
            onPressed: () {
              toastification.show(
                context: context, // optional if you use ToastificationWrapper
                type: ToastificationType.success,
                style: ToastificationStyle.flat,
                autoCloseDuration: const Duration(seconds: 5),
                title: Text('Estacionamento salvo!'),

                alignment: Alignment.topRight,
                direction: TextDirection.ltr,
                animationDuration: const Duration(milliseconds: 300),

                icon: const Icon(Icons.check),
                primaryColor: Colors.green,
                backgroundColor: Colors.white,
                foregroundColor: Colors.black,
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 16),
                margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                borderRadius: BorderRadius.circular(12),
                boxShadow: const [
                  BoxShadow(
                    color: Color(0x07000000),
                    blurRadius: 16,
                    offset: Offset(0, 16),
                    spreadRadius: 0,
                  )
                ],
                showProgressBar: true,
                closeButtonShowType: CloseButtonShowType.onHover,
                closeOnClick: false,
                pauseOnHover: true,
                dragToClose: true,
                applyBlurEffect: true,
                callbacks: ToastificationCallbacks(
                  onTap: (toastItem) => print('Toast ${toastItem.id} tapped'),
                  onCloseButtonTap: (toastItem) => print('Toast ${toastItem.id} close button tapped'),
                  onAutoCompleteCompleted: (toastItem) => print('Toast ${toastItem.id} auto complete completed'),
                  onDismissed: (toastItem) => print('Toast ${toastItem.id} dismissed'),
                ),
              ); // do something
            },
          )
        ],
      ),
      body: ListView(
        children: <Widget>[
          ListTile(
            leading: Icon(Icons.circle, color: Colors.red,),
            title: Text('Vaga 1 - Estacionamento Coberto'),
          ),

          ListTile(
            leading: Icon(Icons.circle, color: Colors.green,),
            title: Text('Vaga 2 - Estacionamento Descoberto'),
          ),
          ListTile(
            leading: Icon(Icons.circle, color: Colors.red,),
            title: Text('Vaga 3 - Estacionamento Coberto'),
          ),

          ListTile(
            leading: Icon(Icons.circle, color: Colors.green,),
            title: Text('Vaga 4 - Estacionamento Descoberto'),
          ), ListTile(
            leading: Icon(Icons.circle, color: Colors.red,),
            title: Text('Vaga 5 - Estacionamento Coberto'),
          ),

          ListTile(
            leading: Icon(Icons.circle, color: Colors.green,),
            title: Text('Vaga 6 - Estacionamento Descoberto'),
          ), ListTile(
            leading: Icon(Icons.circle, color: Colors.red,),
            title: Text('Vaga 7 - Estacionamento Coberto'),
          ),

          ListTile(
            leading: Icon(Icons.circle, color: Colors.green,),
            title: Text('Vaga 8 - Estacionamento Descoberto'),
          ), ListTile(
            leading: Icon(Icons.circle, color: Colors.red,),
            title: Text('Vaga 9 - Estacionamento Coberto'),
          ),

          ListTile(
            leading: Icon(Icons.wheelchair_pickup, color: Colors.blue,),
            title: Text('Vaga 10 - Estacionamento Coberto'),
          ),
        ],
      ),
    );
  }
}
