import 'package:flutter/material.dart';

class Estacionamentotres extends StatefulWidget {
  const Estacionamentotres({super.key});

  @override
  State<Estacionamentotres> createState() => _EstacionamentotresState();
}

class _EstacionamentotresState extends State<Estacionamentotres> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('BravoPark'),
        actions: <Widget>[
          IconButton(
            icon: Icon(
              Icons.add_circle,
              color: Colors.black,
            ),
            onPressed: () {
              // do something
            },
          )
        ],
      ),
    body: ListView(
      children: <Widget>[
        ListTile(
          leading: Icon(Icons.circle, color: Colors.red,),
          title: Text('Vaga 1 - Estacionamento Coberto'),
        ),

        ListTile(
          leading: Icon(Icons.circle, color: Colors.red,),
          title: Text('Vaga 2 - Estacionamento Descoberto'),
        ),
        ListTile(
          leading: Icon(Icons.circle, color: Colors.red,),
          title: Text('Vaga 3 - Estacionamento Coberto'),
        ),

        ListTile(
          leading: Icon(Icons.circle, color: Colors.red,),
          title: Text('Vaga 4 - Estacionamento Descoberto'),
        ), ListTile(
          leading: Icon(Icons.circle, color: Colors.red,),
          title: Text('Vaga 5 - Estacionamento Coberto'),
        ),

        ListTile(
          leading: Icon(Icons.circle, color: Colors.red,),
          title: Text('Vaga 6 - Estacionamento Descoberto'),
        ), ListTile(
          leading: Icon(Icons.circle, color: Colors.red,),
          title: Text('Vaga 7 - Estacionamento Coberto'),
        ),

        ListTile(
          leading: Icon(Icons.circle, color: Colors.red,),
          title: Text('Vaga 8 - Estacionamento Coberto'),
        ),

        ListTile(
          leading: Icon(Icons.circle, color: Colors.red,),
          title: Text('Vaga 9 - Estacionamento Descoberto'),
        ), ListTile(
          leading: Icon(Icons.circle, color: Colors.red,),
          title: Text('Vaga 10 - Estacionamento Coberto'),
        ),
        ListTile(
          leading: Icon(Icons.circle, color: Colors.red,),
          title: Text('Vaga 11 - Estacionamento Descoberto'),
        ), ListTile(
          leading: Icon(Icons.circle, color: Colors.red,),
          title: Text('Vaga 12 - Estacionamento Coberto'),
        ),

        ListTile(
          leading: Icon(Icons.circle, color: Colors.red,),
          title: Text('Vaga 13 - Estacionamento Coberto'),
        ),
        ListTile(
          leading: Icon(Icons.circle, color: Colors.red,),
          title: Text('Vaga 14 - Estacionamento Coberto'),
        ),

        ListTile(
          leading: Icon(Icons.circle, color: Colors.red,),
          title: Text('Vaga 15 - Estacionamento Descoberto'),
        ), ListTile(
          leading: Icon(Icons.circle, color: Colors.red,),
          title: Text('Vaga 16 - Estacionamento Coberto'),
        ),
      ],
    ));
  }
}
