import 'package:flutter/material.dart';

class Estacionamentodois extends StatefulWidget {
  const Estacionamentodois({super.key});

  @override
  State<Estacionamentodois> createState() => _EstacionamentodoisState();
}

class _EstacionamentodoisState extends State<Estacionamentodois> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Seminario'),
        actions: <Widget>[
          IconButton(
            icon: Icon(
              Icons.add_circle,
              color: Colors.black,
            ),
            onPressed: () {
              // do something
            },
          )
        ],
      ),
      body: ListView(
      children: <Widget>[
      ListTile(
      leading: Icon(Icons.wheelchair_pickup, color: Colors.blue,),
    title: Text('Vaga 1 - Estacionamento Coberto'),
    ),

    ListTile(
    leading: Icon(Icons.wheelchair_pickup, color: Colors.blue,),
    title: Text('Vaga 2 - Estacionamento Coberto'),
    ),
    ListTile(
    leading: Icon(Icons.circle, color: Colors.red,),
    title: Text('Vaga 3 - Estacionamento Coberto'),
    ),

    ListTile(
    leading: Icon(Icons.circle, color: Colors.red,),
    title: Text('Vaga 4 - Estacionamento Coberto'),
    ), ListTile(
    leading: Icon(Icons.circle, color: Colors.red,),
    title: Text('Vaga 5 - Estacionamento Coberto'),
    ),

    ListTile(
    leading: Icon(Icons.circle, color: Colors.red,),
    title: Text('Vaga 6 - Estacionamento Descoberto'),
    ), ListTile(
    leading: Icon(Icons.circle, color: Colors.green,),
    title: Text('Vaga 7 - Estacionamento Descoberto'),
    ),

    ListTile(
    leading: Icon(Icons.circle, color: Colors.green,),
    title: Text('Vaga 8 - Estacionamento Descoberto'),
    ), ListTile(
    leading: Icon(Icons.circle, color: Colors.green,),
    title: Text('Vaga 9 - Estacionamento Descoberto'),
    ),

    ListTile(
    leading: Icon(Icons.circle, color: Colors.red,),
    title: Text('Vaga 10 - Estacionamento Descoberto'),
    ),
    ],
    ),
    );
  }
}