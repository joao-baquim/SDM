import 'package:flutter/material.dart';
import 'package:iparking/estacionamento.dart';
import 'package:toastification/toastification.dart';

class Vagasalva extends StatefulWidget {
  const Vagasalva({super.key});

  @override
  State<Vagasalva> createState() => _VagasalvaState();
}

class _VagasalvaState extends State<Vagasalva> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Estacionamentos salvos'),
        actions: <Widget>[
          IconButton(
            icon: Icon(
              Icons.add_circle,
              color: Colors.black,
            ),
            onPressed: () {
              // do something
            },
          )
        ],
      ),
      body: ListView(
        children: <Widget>[


              // GestureDetector(
              //   onTap: () {
              //     Navigator.push(context,
              //         MaterialPageRoute(builder: (context) => Estacionamento()));
              //   },
              //   child: Image.asset("assets/images/Lugar 3.jpg",
              //       width: 50.0, height: 50.0),
              // ),

          ListTile(

            leading: Image.asset("assets/images/Lugar 3.jpg", width: 100, height: 100),
            title: Text('Estapar Estacionamento'),

            onTap: (){
              Navigator.push(context,
                          MaterialPageRoute(builder: (context) => Estacionamento()));

            },
          ),

           SizedBox(
            height: 750,
          ),
          Container(

              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: <Widget>[
                  Container(
                    child: IconButton(
                      icon: Icon(
                        Icons.home,
                        color: Colors.black,
                      ),
                      onPressed: (){
                        Navigator.pop(context);
                      },
                    ),
                  ),
                  Container(
                    child: IconButton(
                      icon: Icon(
                        Icons.add_business_sharp,
                        color: Colors.black,
                      ),
                      onPressed: (){
                        Navigator.push(context,
                            MaterialPageRoute(builder: (context) => Vagasalva()));
                      },
                    ),
                  ),
                  Container(
                    child: IconButton(
                      icon: Icon(
                        Icons.notifications,
                        color: Colors.black,
                      ),
                      onPressed: () {
                        toastification.show(
                          context: context, // optional if you use ToastificationWrapper
                          type: ToastificationType.success,
                          style: ToastificationStyle.flat,
                          autoCloseDuration: const Duration(seconds: 3),
                          title: Text('Sem notificaçoes!'),

                          alignment: Alignment.bottomCenter,
                          direction: TextDirection.ltr,
                          animationDuration: const Duration(milliseconds: 300),

                          icon: const Icon(Icons.error_outline),
                          primaryColor: Colors.red,
                          backgroundColor: Colors.white,
                          foregroundColor: Colors.black,
                          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 16),
                          margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                          borderRadius: BorderRadius.circular(12),
                          boxShadow: const [
                            BoxShadow(
                              color: Color(0x07000000),
                              blurRadius: 16,
                              offset: Offset(0, 16),
                              spreadRadius: 0,
                            )
                          ],
                          showProgressBar: true,
                          closeButtonShowType: CloseButtonShowType.onHover,
                          closeOnClick: false,
                          pauseOnHover: true,
                          dragToClose: true,
                          applyBlurEffect: true,
                          callbacks: ToastificationCallbacks(
                            onTap: (toastItem) => print('Toast ${toastItem.id} tapped'),
                            onCloseButtonTap: (toastItem) => print('Toast ${toastItem.id} close button tapped'),
                            onAutoCompleteCompleted: (toastItem) => print('Toast ${toastItem.id} auto complete completed'),
                            onDismissed: (toastItem) => print('Toast ${toastItem.id} dismissed'),
                          ),
                        );
                      },
                    ),
                  ),



                ],
              )
          )


    ],
      )
    );
  }
}
