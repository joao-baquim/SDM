package com.example.iparking

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
